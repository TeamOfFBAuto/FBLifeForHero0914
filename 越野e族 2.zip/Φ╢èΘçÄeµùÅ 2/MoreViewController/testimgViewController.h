//
//  testimgViewController.h
//  FbLife
//
//  Created by 史忠坤 on 13-9-14.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface testimgViewController : UIViewController
@property(nonatomic,strong)NSMutableArray * allImageArray1;

@end
