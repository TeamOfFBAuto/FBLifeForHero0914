//
//  MyNavigationController.h
//  越野e族
//
//  Created by soulnear on 14-7-11.
//  Copyright (c) 2014年 soulnear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyNavigationController : UINavigationController
{
    
}



+(MyNavigationController *)sharedManager;


@end
