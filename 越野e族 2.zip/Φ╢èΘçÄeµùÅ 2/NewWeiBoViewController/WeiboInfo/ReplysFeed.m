//
//  ReplysFeed.m
//  FblifeAll
//
//  Created by zhang xinhao on 12-11-26.
//  Copyright (c) 2012年 fblife. All rights reserved.
//

#import "ReplysFeed.h"

@implementation ReplysFeed

@synthesize tid =_tid;
@synthesize uid =_uid;
@synthesize username =_username;
@synthesize content =_content;
@synthesize imageid =_imageid;
@synthesize replys =_replys;
@synthesize forwards =_forwards;
@synthesize roottid =_roottid;
@synthesize totid=_totid;
@synthesize touid =_touid;
@synthesize tousername =_tousername;
@synthesize dateline =_dateline;
@synthesize from =_from;
@synthesize sort =_sort;
@synthesize sortid =_sortid;
@synthesize imageSmall =_imageSmall;
@synthesize imageOriginal =_imageOriginal;
@synthesize faceSmall =_faceSmall;
@synthesize faceOriginal =_faceOriginal;


@end