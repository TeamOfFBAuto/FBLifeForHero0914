//
//  WeiBoFaceScrollView.h
//  越野e族
//
//  Created by soulnear on 13-12-27.
//  Copyright (c) 2013年 soulnear. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeiBoFaceScrollView : UIScrollView

- (id)initWithFrame:(CGRect)rect target:(id)target;

@end
