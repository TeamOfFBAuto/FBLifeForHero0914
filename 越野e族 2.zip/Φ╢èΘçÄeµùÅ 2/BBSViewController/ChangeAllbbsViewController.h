//
//  ChangeAllbbsViewController.h
//  FbLife
//
//  Created by 史忠坤 on 13-5-6.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangeAllbbsViewController : UIViewController

@end
