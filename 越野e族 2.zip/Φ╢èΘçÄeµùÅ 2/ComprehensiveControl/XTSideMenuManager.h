//
//  XTSideMenuManager.h
//  XTNews
//
//  Created by tage on 14-5-27.
//  Copyright (c) 2014年 XT. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XTSideMenuManager : NSObject

+ (void)resetSideMenuRecognizerEnable:(BOOL)canOpen;

@end
