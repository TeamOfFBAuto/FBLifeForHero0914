//
//  NewsData.m
//  FbLife
//
//  Created by 史忠坤 on 13-5-15.
//  Copyright (c) 2013年 szk. All rights reserved.
//

#import "NewsData.h"

@implementation NewsData

@end
